package com.example.android.scorekeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    int scoreTeamA=0;
    int scoreTeamB=0;
    int AceTeamA=0;
    int AceTeamB=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        }

    public void ace_A(View view)
    {
        scoreTeamA= scoreTeamA+1;
        AceTeamA= AceTeamA+1;
        displayForTeamA( scoreTeamA);
        displayOfAceForTeamA("ACE: "+AceTeamA);
    }

    public void kill_A(View view)
    {
        scoreTeamA= scoreTeamA+1;
        displayForTeamA( scoreTeamA);
    }

    public void block_A(View view)
    {
        scoreTeamA=scoreTeamA+1;
        displayForTeamA(scoreTeamA);
    }

    public void ace_B(View view)
    {
        scoreTeamB= scoreTeamB+1;
        AceTeamB= AceTeamB+1;
        displayForTeamB( scoreTeamB);
        displayOfAceForTeamB("ACE: "+AceTeamB);
    }

    public void kill_B(View view)
    {
        scoreTeamB= scoreTeamB+1;
        displayForTeamB( scoreTeamB);
    }

    public void block_B(View view)
    {
        scoreTeamB=scoreTeamB+1;
        displayForTeamB(scoreTeamB);
    }

    public void resetS(View v)
    {
        scoreTeamA=0;
        scoreTeamB=0;
        AceTeamA=0;
        AceTeamB=0;
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);
        displayOfAceForTeamA("ACE: "+AceTeamA);
        displayOfAceForTeamB("ACE: "+AceTeamB);
    }
    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int score)
    {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayForTeamB(int score)
    {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }

    public void displayOfAceForTeamA(String score)
    {
        TextView scoreView = (TextView) findViewById(R.id.ace_score_A);
        scoreView.setText(String.valueOf(score));
    }

    public void displayOfAceForTeamB(String score)
    {
        TextView scoreView = (TextView) findViewById(R.id.ace_score_B);
        scoreView.setText(String.valueOf(score));
    }

    public void displayOfAceForTeamB(int score)
    {
        TextView scoreView = (TextView) findViewById(R.id.ace_score_B);
        scoreView.setText(String.valueOf(score));

    }

    public void displayOfAceForTeamA(int score)
    {
        TextView scoreView = (TextView) findViewById(R.id.ace_score_A);
        scoreView.setText(String.valueOf(score));
    }

}
